import type { Product, ProductQuery, SearchSuggestions } from "../types";
import { api } from "./apiClient";

// Products come from the API. The admin dashboard is where they are created and changed.
export function getProducts(query: ProductQuery = {}) {
  const params = new URLSearchParams();
  if (query.category) params.set("category", query.category);
  if (query.q) params.set("q", query.q);
  if (query.sort) params.set("sort", query.sort);
  if (query.offersOnly) params.set("offers", "1"); // only products that have a discount
  return api<Product[]>(`/products?${params}`, { auth: "none" });
}

export const getProduct = (id: number) => api<Product>(`/products/${id}`, { auth: "none" });

export const getSearchSuggestions = (q: string) =>
  api<SearchSuggestions>(`/products/search/suggestions?q=${encodeURIComponent(q)}`, { auth: "none" });
