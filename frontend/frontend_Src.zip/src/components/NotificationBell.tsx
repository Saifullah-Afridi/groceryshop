import { useCallback, useEffect, useRef, useState } from "react";
import { Bell, CheckCheck, CircleAlert, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import {
  createClient,
  type RealtimeChannel,
  type SupabaseClient,
} from "@supabase/supabase-js";

import { api } from "../services/apiClient";

interface NotificationItem {
  id: number;
  title: string;
  message: string;
  orderId: number | null;
  isRead: boolean;
  createdAt: string;
}

type ConnectionState = "connecting" | "connected" | "offline";

/**
 * Notifications are stored by the Rakan API and streamed by Supabase Realtime.
 * A low-frequency fallback is kept only for environments where Realtime is
 * temporarily unavailable; normal updates arrive immediately over the channel.
 */
export function NotificationBell({
  audience,
}: {
  audience: "admin" | "customer";
}) {
  const queryClient = useQueryClient();
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [open, setOpen] = useState(false);
  const [markingAll, setMarkingAll] = useState(false);
  const [connection, setConnection] = useState<ConnectionState>("connecting");
  const root = useRef<HTMLDivElement>(null);
  const connectionRef = useRef<ConnectionState>("connecting");

  const auth = audience;
  const listPath =
    audience === "admin" ? "/notifications/admin" : "/notifications/mine";
  const tokenPath =
    audience === "admin"
      ? "/notifications/admin/realtime-token"
      : "/notifications/mine/realtime-token";
  const unread = items.reduce((count, item) => count + (item.isRead ? 0 : 1), 0);

  const updateConnection = useCallback((state: ConnectionState) => {
    connectionRef.current = state;
    setConnection(state);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const latest = await api<NotificationItem[]>(listPath, { auth });
      setItems(latest);
    } catch {
      // Authentication/session handling is centralized in apiClient.
    }
  }, [auth, listPath]);

  const refreshRelatedData = useCallback(() => {
    if (audience === "admin") {
      void queryClient.invalidateQueries({ queryKey: ["admin", "orders"] });
      void queryClient.invalidateQueries({ queryKey: ["admin-dashboard"] });
    } else {
      void queryClient.invalidateQueries({ queryKey: ["orders", "mine"] });
    }
  }, [audience, queryClient]);

  useEffect(() => {
    let active = true;
    let client: SupabaseClient | null = null;
    let channel: RealtimeChannel | null = null;
    let tokenTimer = 0;
    let retryTimer = 0;
    let fallbackTimer = 0;
    let connecting = false;

    const scheduleRetry = (delay = 5000) => {
      window.clearTimeout(retryTimer);
      retryTimer = window.setTimeout(() => {
        void connect();
      }, delay);
    };

    const handleDatabaseChange = () => {
      if (!active) return;
      void refresh();
      refreshRelatedData();
    };

    const connect = async () => {
      if (!active || connecting) return;
      connecting = true;

      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

      if (!supabaseUrl || !publishableKey) {
        updateConnection("offline");
        connecting = false;
        console.error(
          "Supabase Realtime is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY.",
        );
        return;
      }

      try {
        const result = await api<{ token: string; expiresIn: number }>(
          tokenPath,
          { auth },
        );

        if (!active) return;

        if (!client) {
          client = createClient(supabaseUrl, publishableKey, {
            auth: {
              persistSession: false,
              autoRefreshToken: false,
              detectSessionInUrl: false,
            },
            realtime: {
              params: { eventsPerSecond: 10 },
            },
          });
        }

        await client.realtime.setAuth(result.token);

        if (channel) {
          await client.removeChannel(channel);
          channel = null;
        }

        channel = client
          .channel(
            audience === "admin"
              ? "rakan-notifications-admin"
              : "rakan-notifications-customer",
          )
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: "Notification",
              filter: `audience=eq.${audience === "admin" ? "ADMIN" : "CUSTOMER"}`,
            },
            handleDatabaseChange,
          )
          .subscribe((status) => {
            if (!active) return;

            if (status === "SUBSCRIBED") {
              updateConnection("connected");
              void refresh();
              refreshRelatedData();
              window.clearTimeout(retryTimer);
            } else if (
              status === "CHANNEL_ERROR" ||
              status === "TIMED_OUT" ||
              status === "CLOSED"
            ) {
              updateConnection("offline");
              scheduleRetry(5000);
            }
          });

        window.clearInterval(tokenTimer);
        // Re-authenticate before the short-lived Supabase JWT expires.
        tokenTimer = window.setInterval(() => {
          void connect();
        }, 4 * 60 * 1000);
      } catch (error) {
        if (active) {
          updateConnection("offline");
          console.error("Could not connect to notification Realtime.", error);
          scheduleRetry(10000);
        }
      } finally {
        connecting = false;
      }
    };

    void refresh();
    void connect();

    // Fallback only: keeps the UI usable if Realtime is temporarily disconnected.
    fallbackTimer = window.setInterval(() => {
      if (!active) return;
      if (document.visibilityState === "visible") {
        void refresh();
        if (connectionRef.current !== "connected") refreshRelatedData();
      }
    }, 60000);

    const onFocus = () => {
      void refresh();
      if (connectionRef.current !== "connected") void connect();
    };
    window.addEventListener("focus", onFocus);

    return () => {
      active = false;
      window.clearInterval(tokenTimer);
      window.clearInterval(fallbackTimer);
      window.clearTimeout(retryTimer);
      window.removeEventListener("focus", onFocus);
      if (client) void client.removeAllChannels();
    };
    // Connection state is intentionally read by the fallback timer through its
    // latest render; the Realtime lifecycle depends on audience and API paths.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audience, auth, listPath, tokenPath, refresh, refreshRelatedData, updateConnection]);

  useEffect(() => {
    const close = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    return () => document.removeEventListener("pointerdown", close);
  }, []);

  const markRead = async (id: number) => {
    const path =
      audience === "admin"
        ? `/notifications/admin/${id}/read`
        : `/notifications/mine/${id}/read`;

    setItems((current) =>
      current.map((item) =>
        item.id === id ? { ...item, isRead: true } : item,
      ),
    );

    try {
      await api(path, { method: "POST", auth });
      await refresh();
    } catch {
      await refresh();
    }
  };

  const markAll = async () => {
    if (!unread || markingAll) return;

    const path =
      audience === "admin"
        ? "/notifications/admin/read-all"
        : "/notifications/mine/read-all";

    setMarkingAll(true);
    setItems((current) =>
      current.map((item) => ({ ...item, isRead: true })),
    );

    try {
      await api(path, { method: "POST", auth });
      await refresh();
    } catch {
      await refresh();
    } finally {
      setMarkingAll(false);
    }
  };

  return (
    <div className="relative" ref={root}>
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-label="Notifications"
        aria-expanded={open}
        className={`
          relative grid h-10 w-10 shrink-0 place-items-center rounded-full
          border transition-colors duration-200
          focus:outline-none focus:ring-2 focus:ring-[#078A4B] focus:ring-offset-2
          ${
            audience === "admin"
              ? "border-white/20 bg-white/10 text-white hover:bg-white/20"
              : "border-[#DCEAE1] bg-white text-[#123B2A] hover:bg-[#F0F8F2]"
          }
        `}
      >
        <Bell size={18} />
        {unread > 0 && (
          <span className="absolute -end-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-[#078A4B] px-1 text-[10px] font-bold text-white ring-2 ring-white">
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>

      {open && (
        <section
          role="dialog"
          aria-label="Notifications"
          className="
            absolute end-0 top-full z-[100] mt-3
            flex w-[min(360px,calc(100vw-2rem))]
            flex-col overflow-hidden rounded-2xl
            border border-[#DCEAE1] bg-white text-[#123B2A]
            shadow-[0_18px_55px_rgba(3,29,26,0.18)]
          "
        >
          <header className="flex min-h-[60px] shrink-0 items-center justify-between gap-3 border-b border-[#E8EEE9] px-4 py-3">
            <div className="min-w-0">
              <h3 className="text-sm font-bold">Notifications</h3>
              <p className="mt-0.5 text-[11px] text-[#87958D]">
                {unread > 0 ? `${unread} unread` : "You're all caught up"}
              </p>
            </div>

            <button
              type="button"
              onClick={() => void markAll()}
              disabled={!unread || markingAll}
              className="
                inline-flex h-9 shrink-0 items-center justify-center gap-1.5
                whitespace-nowrap rounded-lg border border-[#DCEAE1]
                bg-white px-3 text-xs font-semibold text-[#078A4B]
                transition-colors hover:bg-[#F0F8F2]
                disabled:cursor-not-allowed disabled:opacity-40
                focus:outline-none focus:ring-2 focus:ring-[#078A4B]
              "
            >
              {markingAll ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <CheckCheck size={14} />
              )}
              <span>Mark all as read</span>
            </button>
          </header>

          {connection === "offline" && (
            <div className="flex items-center gap-2 border-b border-amber-100 bg-amber-50 px-4 py-2 text-[11px] text-amber-800">
              <CircleAlert size={13} className="shrink-0" />
              Live connection interrupted. Reconnecting…
            </div>
          )}

          <div className="max-h-[min(65vh,420px)] overflow-y-auto overscroll-contain">
            {items.length === 0 ? (
              <div className="px-5 py-10 text-center">
                <span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-[#F0F8F2] text-[#078A4B]">
                  <Bell size={19} />
                </span>
                <p className="mt-3 text-sm font-semibold text-[#123B2A]">
                  No notifications yet
                </p>
                <p className="mt-1 text-xs text-[#87958D]">
                  New order and status updates will appear here.
                </p>
              </div>
            ) : (
              items.map((item) => (
                <article
                  key={item.id}
                  className={`
                    border-b border-[#F0F4F1] px-4 py-3.5
                    transition-colors hover:bg-[#F8FBF9]
                    ${item.isRead ? "bg-white" : "bg-[#F0F8F2]"}
                  `}
                >
                  <button
                    type="button"
                    onClick={() => void markRead(item.id)}
                    className="block w-full min-w-0 text-start"
                  >
                    <span className="flex min-w-0 items-start justify-between gap-3">
                      <span className="min-w-0 break-words text-sm font-bold leading-5 text-[#123B2A]">
                        {item.title}
                      </span>
                      {!item.isRead && (
                        <span
                          aria-label="Unread"
                          className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#078A4B]"
                        />
                      )}
                    </span>

                    <span className="mt-1 block break-words text-xs leading-5 text-[#617268]">
                      {item.message}
                    </span>

                    <time
                      dateTime={item.createdAt}
                      className="mt-2 block text-[10px] text-[#87958D]"
                    >
                      {new Date(item.createdAt).toLocaleString()}
                    </time>
                  </button>

                  {item.orderId && (
                    <Link
                      to={
                        audience === "admin"
                          ? "/admin/orders"
                          : "/orders"
                      }
                      onClick={() => {
                        if (!item.isRead) void markRead(item.id);
                        setOpen(false);
                      }}
                      className="
                        mt-2 inline-flex min-h-7 items-center
                        text-xs font-bold text-[#078A4B]
                        hover:text-[#045E34] hover:underline
                      "
                    >
                      View order #{item.orderId}
                    </Link>
                  )}
                </article>
              ))
            )}
          </div>

          <footer className="flex shrink-0 items-center justify-between border-t border-[#E8EEE9] bg-[#FBFDFC] px-4 py-2.5 text-[10px] text-[#87958D]">
            <span>
              {connection === "connected"
                ? "Live updates enabled"
                : "Waiting for live connection"}
            </span>
            <button
              type="button"
              onClick={() => void refresh()}
              className="font-semibold text-[#078A4B] hover:underline"
            >
              Refresh
            </button>
          </footer>
        </section>
      )}
    </div>
  );
}
