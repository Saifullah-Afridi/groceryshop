import { httpError } from "../../lib/httpError.js";
import { prisma } from "../../lib/prisma.js";
import { slugify } from "../../lib/slug.js";
import { deleteImage, uploadImage } from "../../lib/storage.js";
import { buildBilingualContent } from "../../lib/translate.js";

// The shape the React app expects.
const toDto = (c) => ({
  id: c.id,
  name: c.name,
  nameAr: c.nameAr,
  icon: c.icon,
  color: c.color,
  tint: c.tint,
  image: c.image ?? "",
});

async function findOrFail(id) {
  const category = await prisma.category.findUnique({ where: { id } });
  if (!category) throw httpError(404, "Category not found.");
  return category;
}

export async function listCategories({ page, limit, search = "", sort = "oldest" } = {}) {
  const where = search ? { OR: [
    { name: { contains: search, mode: "insensitive" } },
    { nameAr: { contains: search, mode: "insensitive" } },
  ] } : {};
  const orderBy = sort === "newest" ? [{ createdAt: "desc" }, { id: "desc" }]
    : sort === "name-desc" ? [{ name: "desc" }, { id: "desc" }]
    : sort === "name-asc" ? [{ name: "asc" }, { id: "asc" }]
    : [{ createdAt: "asc" }, { id: "asc" }];
  if (page && limit) {
    const skip = (page - 1) * limit;
    const [rows, total] = await prisma.$transaction([
      prisma.category.findMany({ where, skip, take: limit, orderBy }),
      prisma.category.count({ where }),
    ]);
    const totalPages = Math.ceil(total / limit);
    return { data: rows.map(toDto), pagination: { page, limit, total, totalPages, hasNextPage: page < totalPages, hasPreviousPage: page > 1 && totalPages > 0 } };
  }
  const rows = await prisma.category.findMany({ orderBy });
  return rows.map(toDto);
}

export async function getCategory(id) {
  return toDto(await findOrFail(id));
}

export async function createCategory(data, file) {
  const bilingual = await buildBilingualContent(data, data.language, {}, ["name"]);
  const { language, name, removeImage, ...rest } = data;
  data = { ...rest, ...bilingual };
  const id = slugify(data.name) || `category-${Date.now()}`;
  if (await prisma.category.findUnique({ where: { id } })) {
    throw httpError(409, "A category with this name already exists.");
  }
  const image = file ? await uploadImage(file, "categories") : null;
  try {
    return toDto(await prisma.category.create({ data: { id, ...data, image } }));
  } catch (error) {
    await deleteImage(image); // do not leave an unused file behind
    throw error;
  }
}

export async function updateCategory(id, data, file) {
  const current = await findOrFail(id);
  const bilingual = await buildBilingualContent(data, data.language ?? "en", current, ["name"]);
  const { language, name, ...rest } = data;
  data = { ...rest, ...bilingual };
  const image = file ? await uploadImage(file, "categories") : undefined;
  const shouldRemoveImage = Boolean(data.removeImage) && !file;
  delete data.removeImage;
  try {
    const row = await prisma.category.update({
      where: { id },
      data: { ...data, ...(image ? { image } : shouldRemoveImage ? { image: null } : {}) },
    });
    if (image || shouldRemoveImage) await deleteImage(current.image); // remove the old photo after the database update
    return toDto(row);
  } catch (error) {
    await deleteImage(image);
    throw error;
  }
}

export async function deleteCategory(id) {
  const current = await findOrFail(id);
  const used = await prisma.product.count({ where: { categoryId: id } });
  if (used > 0) throw httpError(409, `This category still has ${used} products. Move or delete them first.`);
  await prisma.category.delete({ where: { id } });
  await deleteImage(current.image);
}
